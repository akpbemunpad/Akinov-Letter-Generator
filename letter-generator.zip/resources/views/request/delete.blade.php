@extends('template.layout')

@section('nl-request', 'active')

@section('content')
    <div class="row">
        <div class="col">
            <h3>Permanent Letter Delete Confirmation.</h3>
            <hr>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <form action="{{ url('/' . $letterType) }}" method="post">
                @csrf
                @method('DELETE')
                <div class="form-group">
                    <span>
                        Are you sure want to delete <b>{{ $letter->file_name }}</b> letter?
                        <input type="hidden" name="letterId" value="{{ $letter->id }}">
                        <input type="hidden" name="letterFileId" value="{{ $letter->file_name }}">
                    </span>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-danger">Yes, i am sure</button>
                    <a href="{{ url('/') }}" type="button" class="btn btn-secondary">No, i want to cancel</a>
                </div>
            </form>
        </div>
    </div>
@endsection