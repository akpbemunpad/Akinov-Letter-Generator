

<?php $__env->startSection('nl-request', 'active'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <h3>List of basic letter.</h3>
             <hr>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <table class="table table-sm table-striped">
                <thead class="thead-dark">
                  <tr>
                    <th scope="col">Nomor</th>
                    <th scope="col">File</th>
                    <th scope="col">Ttd Kadep</th>
                    <th scope="col">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $basicLetters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <th scope="row"><?php echo e($l->letter_ref_number); ?></th>
                            <td>
                                <?php if( $l->acc_hod and $l->event_name != 'custom letter' ): ?>
                                    <a href="<?php echo e(url('storage\\' . $l->file_name)); ?>"><?php echo e($l->file_name); ?></a>
                                <?php else: ?>
                                    <span><?php echo e($l->file_name); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if( $l->acc_hod ): ?>
                                    <span class="badge badge-secondary">Signed</span>
                                <?php else: ?>
                                    <a href="<?php echo e(url('sign/1/' . $l->id )); ?>" class="badge badge-primary">Tanda Tangan</a>
                                <?php endif; ?>
                                
                            </td>
                            <td>
                                <a href="<?php echo e(url('basic/edit/' . $l->id )); ?>" class="badge badge-info">Edit</a>
                                <a href="<?php echo e(url('basic/delete/' . $l->id )); ?>" class="badge badge-danger">Hapus</a>
                            </td>
                        </tr> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <a href="<?php echo e(url('basic/create')); ?>" type="button" class="btn btn-success">Buat Surat Basic</a>
            <a href="<?php echo e(url('basic/custom')); ?>" type="button" class="btn btn-secondary">Buat Surat Custom</a>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col">
            <h3>List of application for a letter of assignment.</h3>
             <hr>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <table class="table table-sm table-striped">
                <thead class="thead-dark">
                  <tr>
                    <th scope="col">Nomor</th>
                    <th scope="col">File</th>
                    <th scope="col">Ttd Kadep</th>
                    <th scope="col">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $internalInvitationLetters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <th scope="row"><?php echo e($l->letter_ref_number); ?></th>
                            <td>
                                <?php if( $l->acc_hod and $l->event_name != 'custom letter' ): ?>
                                    <a href="<?php echo e(url('storage\\' . $l->file_name)); ?>"><?php echo e($l->file_name); ?></a>
                                <?php else: ?>
                                    <span><?php echo e($l->file_name); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if( $l->acc_hod ): ?>
                                    <span class="badge badge-secondary">Signed</span>
                                <?php else: ?>
                                    <a href="<?php echo e(url('sign/2/' . $l->id )); ?>" class="badge badge-primary">Tanda Tangan</a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(url('invitation/internal/edit/' . $l->id )); ?>" class="badge badge-info">Edit</a>
                                <a href="<?php echo e(url('invitation/internal/delete/' . $l->id )); ?>" class="badge badge-danger">Hapus</a>
                            </td>
                        </tr> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <a href="<?php echo e(url('invitation/internal/create' )); ?>" type="button" class="btn btn-success">Buat Surat Permohonan Pemateri/Pembicara</a>
            <a href="<?php echo e(url('invitation/internal/custom')); ?>" type="button" class="btn btn-secondary">Buat Surat Custom</a>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col">
            <h3>List of invitation letter.</h3>
             <hr>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <table class="table table-sm table-striped">
                <thead class="thead-dark">
                  <tr>
                    <th scope="col">Nomor</th>
                    <th scope="col">File</th>
                    <th scope="col">Ttd Kadep</th>
                    <th scope="col">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $externalInvitationLetters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <th scope="row"><?php echo e($l->letter_ref_number); ?></th>
                            <td>
                                <?php if( $l->acc_hod and $l->event_name != 'custom letter' ): ?>
                                    <a href="<?php echo e(url('storage\\' . $l->file_name)); ?>"><?php echo e($l->file_name); ?></a>
                                <?php else: ?>
                                    <span><?php echo e($l->file_name); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if( $l->acc_hod ): ?>
                                    <span class="badge badge-secondary">Signed</span>
                                <?php else: ?>
                                    <a href="<?php echo e(url('sign/3/' . $l->id )); ?>" class="badge badge-primary">Tanda Tangan</a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(url('invitation/external/edit/' . $l->id )); ?>" class="badge badge-info">Edit</a>
                                <a href="<?php echo e(url('invitation/external/delete/' . $l->id )); ?>" class="badge badge-danger">Hapus</a>
                            </td>
                        </tr> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <a href="<?php echo e(url('invitation/external/create' )); ?>" type="button" class="btn btn-success">Buat Surat Undangan</a>
            <a href="<?php echo e(url('invitation/external/custom')); ?>" type="button" class="btn btn-secondary">Buat Surat Custom</a>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col">
            <h3>List of other letter.</h3>
             <hr>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <table class="table table-sm table-striped">
                <thead class="thead-dark">
                  <tr>
                    <th scope="col">Nomor</th>
                    <th scope="col">File</th>
                    <th scope="col">Ttd Kadep</th>
                    <th scope="col">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $otherLetters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <th scope="row"><?php echo e($l->letter_ref_number); ?></th>
                            <td>
                                <span><?php echo e($l->file_name); ?></span>
                            </td>
                            <td>
                                <?php if( $l->acc_hod ): ?>
                                    <span class="badge badge-secondary">Signed</span>
                                <?php else: ?>
                                    <a href="<?php echo e(url('sign/4/' . $l->id )); ?>" class="badge badge-primary">Tanda Tangan</a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(url('other/edit/' . $l->id )); ?>" class="badge badge-info">Edit</a>
                                <a href="<?php echo e(url('other/delete/' . $l->id )); ?>" class="badge badge-danger">Hapus</a>
                            </td>
                        </tr> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <a href="<?php echo e(url('other/create' )); ?>" type="button" class="btn btn-success">Buat Surat Lainnya</a>
            <a href="<?php echo e(url('other/custom')); ?>" type="button" class="btn btn-secondary">Buat Surat Custom</a>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col">
            <h3>Another action button.</h3>
             <hr>
        </div>
    </div>

    <div class="row mt-2">
        <div class="col">
            <a href="https://docs.google.com/spreadsheets/d/1njAAkYRgGcklkAR04xqPWhhrawslfsrvsYkfftDi5TM/edit?usp=sharing" target="_blank" type="button" class="btn btn-info">Lihat Spreadsheet Progress</a>
            <a href="https://drive.google.com/drive/folders/1r3xc25Lgp8fwz62KjcBz0ES7P-SUSkwW?usp=sharing" target="_blank" type="button" class="btn btn-info">Lihat Surat Selesai</a>
            <a href="https://drive.google.com/drive/folders/1mBX-F5pjkR8CJ_cP1PZkzUBMbjtvq0nc?usp=sharing" target="_blank" type="button" class="btn btn-info">Lihat Siat Didanai</a>
            <a href="https://drive.google.com/drive/folders/1q-iuhEJOv7ZLwQHoDOpGfWecqlu_v2Lc?usp=sharing" target="_blank" type="button" class="btn btn-info">Lihat Format Surat Word</a>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col">
            <h3>Indexes.</h3>
             <hr>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <table class="table table-sm table-striped">
                <thead class="thead-dark">
                  <tr>
                    <th scope="col">Singkatan</th>
                    <th scope="col">Keterangan</th>
                  </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>SIK</td>
                        <td>Permohonan Surat Izin Kegiatan</td>
                    </tr> 

                    <tr>
                        <td>SPDR</td>
                        <td>Permohonan Dana ke Rektorat</td>
                    </tr> 

                    <tr>
                        <td>STP</td>
                        <td>Permohonan Surat Tugas Panitia</td>
                    </tr>

                    <tr>
                        <td>SPM</td>
                        <td>Permohonan Surat Tugas Pemateri atau Pembicara Pegawai Unpad</td>
                    </tr> 

                    <tr>
                        <td>UPL</td>
                        <td>Permohonan Surat Tugas Pemateri atau Pembicara Eksternal</td>
                    </tr> 
                </tbody>
              </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\letter-generator\resources\views/request/index.blade.php ENDPATH**/ ?>