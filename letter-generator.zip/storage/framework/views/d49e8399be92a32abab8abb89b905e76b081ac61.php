

<?php $__env->startSection('nl-request', 'active'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <h3>Letter Signing Confirmation.</h3>
            <hr>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <form action="<?php echo e(url('/request/sign/' . $letterType)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <span>
                        Are you sure want to sign the <b><?php echo e($letter->file_name); ?></b> letter?
                        <input type="hidden" name="letter_id" value="<?php echo e($letter->id); ?>">
                        <input type="hidden" name="letter_file_name" value="<?php echo e($letter->file_name); ?>">
                    </span>
                    <?php if( $preview ): ?>
                        <div class="embed-responsive embed-responsive-4by3">
                            <iframe class="embed-responsive-item" src="https://docs.google.com/gview?url=<?php echo e(url('storage\\' . $letter->file_name)); ?>&embedded=true"></iframe>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-success">Yes, i am sure</button>
                    <a href="<?php echo e(url('/request')); ?>" type="button" class="btn btn-secondary">No, i want to cancel</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\letter-generator\resources\views/request/sign.blade.php ENDPATH**/ ?>