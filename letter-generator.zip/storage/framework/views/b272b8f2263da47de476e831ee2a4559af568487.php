

<?php $__env->startSection('nl-request', 'active'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-5">
        <?php if( $job == 'create' ): ?>
            <h3>Create an other letter.</h3>
        <?php elseif( $job == 'edit' ): ?>
            <h3>Edit an other letter.</h3>
        <?php endif; ?>
      <hr>
    </div>
  </div>

<?php if($errors->any()): ?>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="row">
    <div class="col-lg-5">
      <div class="alert alert-danger" role="alert">
        <?php echo e($error); ?>

      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(isset($result)): ?>
  <div class="row">
    <div class="col-lg-5">
      <div class="alert alert-<?php echo e($result); ?>" role="alert">
        <?php echo e($message); ?>

      </div>
    </div>
  </div>
<?php endif; ?>

  <div class="row">
    <div class="col-lg-5">
      <form action="<?= url('/request/other/' . $job) ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($letter->id ?? ''); ?>">
        <div class="form-group">
          <label for="file_name">File Name: </label>
          <input type="text" class="form-control" name="file_name" id="file_name">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </div>

  <div class="row my-4">
  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\letter-generator\resources\views/request/create/other.blade.php ENDPATH**/ ?>