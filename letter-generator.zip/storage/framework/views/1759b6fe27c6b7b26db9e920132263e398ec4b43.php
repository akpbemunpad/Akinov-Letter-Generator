

<?php $__env->startSection('nl-request', 'active'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-5">
      <h3>Create a custom letter.</h3>
      <hr>
    </div>
  </div>

  <div class="row">
    <div class="col-lg-5">
      <div class="alert alert-warning" role="alert">
        Selain Fikri dilarang ada yang isi halaman ini!
      </div>
    </div>
  </div>
<?php if($errors->any()): ?>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="row">
    <div class="col-lg-5">
      <div class="alert alert-danger" role="alert">
        <?php echo e($error); ?>

      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(isset($result)): ?>
  <div class="row">
    <div class="col-lg-5">
      <div class="alert alert-<?php echo e($result); ?>" role="alert">
        <?php echo e($message); ?>

      </div>
    </div>
  </div>
<?php endif; ?>

  <div class="row">
    <div class="col-lg-5">
      <form action="<?= url('/' . $letterType . '/custom') ?>" method="post" autocomplete="off">
        <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="letter_ref_number">Letter Ref Number: </label>
          <input type="number" class="form-control" name="letter_ref_number" id="letter_ref_number">
        </div>
        <div class="form-group">
          <label for="file_name">File Name: </label>
          <input type="text" class="form-control" name="file_name" id="file_name">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </div>

  <div class="row my-4">
  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\letter-generator\resources\views/request/create/custom.blade.php ENDPATH**/ ?>