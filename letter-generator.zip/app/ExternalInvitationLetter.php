<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExternalInvitationLetter extends Model
{
    //
}
